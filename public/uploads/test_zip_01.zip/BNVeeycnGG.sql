/*
 Navicat Premium Data Transfer

 Source Server         : class_api
 Source Server Type    : MySQL
 Source Server Version : 80013
 Source Host           : remotemysql.com:3306
 Source Schema         : BNVeeycnGG

 Target Server Type    : MySQL
 Target Server Version : 80013
 File Encoding         : 65001

 Date: 19/01/2022 18:07:09
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for SequelizeMeta
-- ----------------------------
DROP TABLE IF EXISTS `SequelizeMeta`;
CREATE TABLE `SequelizeMeta`  (
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`name`) USING BTREE,
  UNIQUE INDEX `name`(`name`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of SequelizeMeta
-- ----------------------------
INSERT INTO `SequelizeMeta` VALUES ('20220106162853-addIsAdminColumn.js');
INSERT INTO `SequelizeMeta` VALUES ('20220111034456-addStatus.js');

-- ----------------------------
-- Table structure for assignments
-- ----------------------------
DROP TABLE IF EXISTS `assignments`;
CREATE TABLE `assignments`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `point` float NULL DEFAULT NULL,
  `order` int(11) NULL DEFAULT NULL,
  `finalize` tinyint(1) NULL DEFAULT 0,
  `createdAt` datetime(0) NOT NULL,
  `updatedAt` datetime(0) NOT NULL,
  `classId` int(11) NULL DEFAULT NULL,
  `creatorId` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `id`(`id`) USING BTREE,
  INDEX `classId`(`classId`) USING BTREE,
  INDEX `creatorId`(`creatorId`) USING BTREE,
  CONSTRAINT `assignments_ibfk_1` FOREIGN KEY (`classId`) REFERENCES `classes` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `assignments_ibfk_2` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 22 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of assignments
-- ----------------------------
INSERT INTO `assignments` VALUES (1, 'Final', 6, 3, 1, '2021-12-20 13:38:07', '2022-01-13 04:38:59', 5, 11);
INSERT INTO `assignments` VALUES (2, 'Test 1', 2, 1, 1, '2021-12-20 13:38:15', '2022-01-13 04:38:43', 5, 11);
INSERT INTO `assignments` VALUES (3, 'Mid Term', 5, 2, 1, '2021-12-20 13:38:23', '2022-01-13 04:38:51', 5, 11);
INSERT INTO `assignments` VALUES (4, 'Oral test', 1, 0, 1, '2021-12-20 13:38:31', '2022-01-13 04:37:23', 5, 11);
INSERT INTO `assignments` VALUES (7, 'Midterm', 3, 2, 1, '2021-12-20 13:52:04', '2022-01-18 03:29:39', 2, 4);
INSERT INTO `assignments` VALUES (8, 'Final Project', 5, 3, 1, '2021-12-20 13:52:14', '2022-01-18 03:29:39', 2, 4);
INSERT INTO `assignments` VALUES (9, 'mid', 7, 2, 1, '2021-12-20 18:29:15', '2022-01-18 15:43:33', 4, 2);
INSERT INTO `assignments` VALUES (10, 'exercise', 5, 1, 0, '2021-12-20 18:29:35', '2022-01-18 03:53:01', 4, 2);
INSERT INTO `assignments` VALUES (11, 'final', 15, 0, 0, '2021-12-20 18:29:55', '2022-01-18 03:53:01', 4, 2);
INSERT INTO `assignments` VALUES (12, 'BTVN 1', 1, 0, 1, '2022-01-10 12:26:42', '2022-01-18 03:29:38', 2, 4);
INSERT INTO `assignments` VALUES (13, 'BTVN 2', 2, 1, 1, '2022-01-10 12:26:51', '2022-01-18 03:29:38', 2, 4);
INSERT INTO `assignments` VALUES (26, 'BTVN 2', 1, 1, 0, '2022-01-18 13:02:24', '2022-01-18 13:18:10', 9, 4);
INSERT INTO `assignments` VALUES (27, 'midterm', 3, 0, 0, '2022-01-18 13:12:33', '2022-01-18 13:13:30', 6, 2);
INSERT INTO `assignments` VALUES (29, 'final term', 4, 1, 0, '2022-01-18 13:12:55', '2022-01-18 13:13:30', 6, 2);
INSERT INTO `assignments` VALUES (30, 'BTVN 1', 1, 0, 0, '2022-01-18 13:18:05', '2022-01-18 13:18:09', 9, 4);

-- ----------------------------
-- Table structure for classes
-- ----------------------------
DROP TABLE IF EXISTS `classes`;
CREATE TABLE `classes`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `className` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `subject` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `description` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `cjc` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `createdAt` datetime(0) NOT NULL,
  `updatedAt` datetime(0) NOT NULL,
  `ownerId` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `id`(`id`) USING BTREE,
  INDEX `ownerId`(`ownerId`) USING BTREE,
  CONSTRAINT `classes_ibfk_1` FOREIGN KEY (`ownerId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 15 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of classes
-- ----------------------------
INSERT INTO `classes` VALUES (2, 'Master Sequelize in 1 hour', 'WEB development', 'Learn one of the most powerful ORM libraries', 'egThd', '2021-11-24 14:04:43', '2021-11-24 14:04:43', 4);
INSERT INTO `classes` VALUES (3, 'OOP programming C++', 'Fundamental', 'A required class for beginners', 'UhvEg', '2021-11-24 14:06:02', '2021-11-24 14:06:02', 4);
INSERT INTO `classes` VALUES (4, 'PTUDW', 'Web', 'Web 1', 'aHhjs', '2021-11-24 14:08:22', '2021-11-24 14:08:23', 2);
INSERT INTO `classes` VALUES (5, 'Anh Văn 3', 'abc', 'abc', 'eyaym', '2021-11-29 14:04:52', '2021-11-29 14:04:52', 11);
INSERT INTO `classes` VALUES (6, 'token', 'stupid', 'nub', '4f962', '2021-11-30 07:04:00', '2021-11-30 07:04:01', 2);
INSERT INTO `classes` VALUES (7, 'Mobile', 'DT android', 'lap trinh android', 'rf6ux', '2021-11-30 09:25:57', '2021-11-30 09:25:57', 2);
INSERT INTO `classes` VALUES (8, 'cuong\'s class', 'cucl', '123', 'gkw7x', '2021-11-30 16:54:25', '2021-11-30 16:54:25', 10);
INSERT INTO `classes` VALUES (9, 'Redux basic', 'WEB development', 'a third-party library', '5oa8b', '2021-12-19 11:20:38', '2021-12-19 11:20:38', 4);
INSERT INTO `classes` VALUES (10, 'Game development', 'Software', 'Nothing', 'm3w4s', '2021-12-19 13:09:37', '2021-12-19 13:09:38', 4);
INSERT INTO `classes` VALUES (11, 'he', 'he', 'heee', 'vpff7', '2021-12-22 03:42:01', '2021-12-22 03:42:01', 14);
INSERT INTO `classes` VALUES (12, 'Demo class', 'Demo', 'class for demo', 'ewj6f', '2022-01-18 12:35:25', '2022-01-18 12:35:25', NULL);
INSERT INTO `classes` VALUES (13, 'Demo class', 'demoo', 'class for demo', 'bvcez', '2022-01-18 12:37:22', '2022-01-18 12:37:22', NULL);
INSERT INTO `classes` VALUES (14, 'class demo', 'demo', 'class for demoo', '03c1c', '2022-01-18 12:39:43', '2022-01-18 12:39:43', 2);

-- ----------------------------
-- Table structure for commentGradeReviews
-- ----------------------------
DROP TABLE IF EXISTS `commentGradeReviews`;
CREATE TABLE `commentGradeReviews`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `createdAt` datetime(0) NOT NULL,
  `updatedAt` datetime(0) NOT NULL,
  `userId` int(11) NULL DEFAULT NULL,
  `gradeReviewId` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `id`(`id`) USING BTREE,
  INDEX `userId`(`userId`) USING BTREE,
  INDEX `gradeReviewId`(`gradeReviewId`) USING BTREE,
  CONSTRAINT `commentGradeReviews_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `commentGradeReviews_ibfk_2` FOREIGN KEY (`gradeReviewId`) REFERENCES `gradeReviews` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 12 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of commentGradeReviews
-- ----------------------------
INSERT INTO `commentGradeReviews` VALUES (15, 'Để thầy xem!', '2022-01-18 14:25:20', '2022-01-18 14:25:21', 4, 12);
INSERT INTO `commentGradeReviews` VALUES (16, 'Dạ em cám ơn thầy ạ', '2022-01-18 14:25:39', '2022-01-18 14:25:39', 12, 12);

-- ----------------------------
-- Table structure for gradeReviews
-- ----------------------------
DROP TABLE IF EXISTS `gradeReviews`;
CREATE TABLE `gradeReviews`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `expectedGrade` float NULL DEFAULT NULL,
  `reviewMessage` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `status` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT 'pending',
  `createdAt` datetime(0) NOT NULL,
  `updatedAt` datetime(0) NOT NULL,
  `userId` int(11) NULL DEFAULT NULL,
  `assignmentId` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `id`(`id`) USING BTREE,
  INDEX `userId`(`userId`) USING BTREE,
  INDEX `assignmentId`(`assignmentId`) USING BTREE,
  CONSTRAINT `gradeReviews_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `gradeReviews_ibfk_2` FOREIGN KEY (`assignmentId`) REFERENCES `assignments` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 11 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of gradeReviews
-- ----------------------------
INSERT INTO `gradeReviews` VALUES (7, 10, 'abc', 'pending', '2022-01-12 14:20:41', '2022-01-12 16:21:38', 2, 4);
INSERT INTO `gradeReviews` VALUES (12, 9, 'Mong thầy coi lại ạ!', 'approved', '2022-01-18 14:24:32', '2022-01-18 14:25:54', 12, 7);
INSERT INTO `gradeReviews` VALUES (13, 10, 'Em làm đúng hết mà ạ!', 'denied', '2022-01-18 14:24:48', '2022-01-18 14:26:13', 12, 13);

-- ----------------------------
-- Table structure for grades
-- ----------------------------
DROP TABLE IF EXISTS `grades`;
CREATE TABLE `grades`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `grade` float NULL DEFAULT NULL,
  `createdAt` datetime(0) NOT NULL,
  `updatedAt` datetime(0) NOT NULL,
  `studentIdFk` int(11) NULL DEFAULT NULL,
  `assignmentId` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `id`(`id`) USING BTREE,
  INDEX `studentIdFk`(`studentIdFk`) USING BTREE,
  INDEX `assignmentId`(`assignmentId`) USING BTREE,
  CONSTRAINT `grades_ibfk_1` FOREIGN KEY (`studentIdFk`) REFERENCES `studentFullnames` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `grades_ibfk_2` FOREIGN KEY (`assignmentId`) REFERENCES `assignments` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 41 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of grades
-- ----------------------------
INSERT INTO `grades` VALUES (1, 10, '2021-12-20 13:40:46', '2021-12-20 13:40:46', 20, 2);
INSERT INTO `grades` VALUES (2, 9, '2021-12-20 13:40:47', '2021-12-20 13:40:47', 32, 2);
INSERT INTO `grades` VALUES (3, 10, '2021-12-20 13:40:48', '2021-12-20 13:40:48', 33, 2);
INSERT INTO `grades` VALUES (4, 9, '2021-12-20 17:30:45', '2021-12-20 17:30:45', 20, 4);
INSERT INTO `grades` VALUES (5, 8, '2021-12-20 17:30:45', '2021-12-20 17:30:45', 21, 1);
INSERT INTO `grades` VALUES (6, 9, '2021-12-20 17:30:45', '2021-12-20 17:30:45', 22, 3);
INSERT INTO `grades` VALUES (7, 10, '2021-12-20 17:30:45', '2021-12-20 17:30:45', 32, 3);
INSERT INTO `grades` VALUES (8, 8, '2021-12-20 17:30:46', '2021-12-20 17:30:46', 33, 3);
INSERT INTO `grades` VALUES (9, 9, '2021-12-20 17:31:15', '2021-12-20 17:34:07', 20, 3);
INSERT INTO `grades` VALUES (16, 10, '2021-12-21 01:20:43', '2022-01-05 15:17:45', 23, 8);
INSERT INTO `grades` VALUES (18, 10, '2022-01-05 15:01:30', '2022-01-05 15:01:30', 24, 8);
INSERT INTO `grades` VALUES (19, 10, '2022-01-05 15:01:31', '2022-01-05 15:01:31', 25, 8);
INSERT INTO `grades` VALUES (20, 9, '2022-01-05 15:02:51', '2022-01-18 14:25:54', 23, 7);
INSERT INTO `grades` VALUES (21, 9, '2022-01-06 07:22:40', '2022-01-06 07:22:40', 24, 7);
INSERT INTO `grades` VALUES (22, 8, '2022-01-06 07:22:41', '2022-01-06 07:22:41', 25, 7);
INSERT INTO `grades` VALUES (23, 8, '2022-01-10 12:28:37', '2022-01-18 14:11:57', 23, 13);
INSERT INTO `grades` VALUES (24, 1, '2022-01-10 12:28:38', '2022-01-10 12:28:38', 24, 13);
INSERT INTO `grades` VALUES (25, 1, '2022-01-10 12:28:39', '2022-01-10 12:28:39', 25, 13);
INSERT INTO `grades` VALUES (26, 10, '2022-01-12 08:48:30', '2022-01-18 09:47:27', 23, 12);
INSERT INTO `grades` VALUES (27, 9, '2022-01-12 14:01:55', '2022-01-12 14:01:55', 20, 1);
INSERT INTO `grades` VALUES (28, 3, '2022-01-12 14:01:55', '2022-01-12 14:01:55', 40, 4);
INSERT INTO `grades` VALUES (29, 9, '2022-01-12 14:01:56', '2022-01-12 14:01:56', 40, 1);
INSERT INTO `grades` VALUES (30, 4, '2022-01-12 14:01:56', '2022-01-12 14:01:56', 40, 2);
INSERT INTO `grades` VALUES (31, 8, '2022-01-12 14:01:56', '2022-01-12 14:01:56', 40, 3);
INSERT INTO `grades` VALUES (32, 8, '2022-01-13 04:39:41', '2022-01-13 04:39:41', 19, 2);
INSERT INTO `grades` VALUES (33, 10, '2022-01-13 04:39:41', '2022-01-13 04:39:41', 19, 3);
INSERT INTO `grades` VALUES (34, 8, '2022-01-13 04:39:41', '2022-01-13 04:39:41', 19, 1);
INSERT INTO `grades` VALUES (35, 8, '2022-01-13 04:39:43', '2022-01-13 04:39:43', 21, 2);
INSERT INTO `grades` VALUES (36, 10, '2022-01-13 04:39:43', '2022-01-13 04:39:43', 21, 3);
INSERT INTO `grades` VALUES (37, 8, '2022-01-13 04:39:44', '2022-01-13 04:39:44', 22, 2);
INSERT INTO `grades` VALUES (38, 9, '2022-01-18 02:50:00', '2022-01-18 02:50:00', 24, 12);
INSERT INTO `grades` VALUES (39, 9.5, '2022-01-18 02:50:01', '2022-01-18 02:50:01', 25, 12);
INSERT INTO `grades` VALUES (40, 5, '2022-01-18 08:51:38', '2022-01-18 15:18:51', 37, 9);
INSERT INTO `grades` VALUES (41, 10, '2022-01-18 15:22:14', '2022-01-18 15:22:14', 37, 11);
INSERT INTO `grades` VALUES (42, 8, '2022-01-18 15:22:15', '2022-01-18 15:22:15', 38, 11);
INSERT INTO `grades` VALUES (43, 10, '2022-01-18 15:40:13', '2022-01-18 15:40:13', 37, 10);
INSERT INTO `grades` VALUES (44, 8, '2022-01-18 15:40:13', '2022-01-18 15:40:13', 52, 10);
INSERT INTO `grades` VALUES (45, 9, '2022-01-18 15:40:51', '2022-01-18 15:40:51', 52, 9);

-- ----------------------------
-- Table structure for notifications
-- ----------------------------
DROP TABLE IF EXISTS `notifications`;
CREATE TABLE `notifications`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` enum('finalize_grade','grade_review_reply','grade_review_final','grade_review_request') CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `createdAt` datetime(0) NOT NULL,
  `updatedAt` datetime(0) NOT NULL,
  `from` int(11) NULL DEFAULT NULL,
  `to` int(11) NULL DEFAULT NULL,
  `classId` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `id`(`id`) USING BTREE,
  INDEX `from`(`from`) USING BTREE,
  INDEX `to`(`to`) USING BTREE,
  INDEX `classId`(`classId`) USING BTREE,
  CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`from`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `notifications_ibfk_2` FOREIGN KEY (`to`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `notifications_ibfk_3` FOREIGN KEY (`classId`) REFERENCES `classes` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 65 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of notifications
-- ----------------------------
INSERT INTO `notifications` VALUES (47, 'grade_review_final', '2022-01-12 16:20:14', '2022-01-12 16:20:14', 11, 2, 5);
INSERT INTO `notifications` VALUES (48, 'grade_review_final', '2022-01-12 16:21:39', '2022-01-12 16:21:39', 11, 2, 5);
INSERT INTO `notifications` VALUES (49, 'grade_review_final', '2022-01-12 16:27:04', '2022-01-12 16:27:04', 11, 2, 5);
INSERT INTO `notifications` VALUES (50, 'grade_review_reply', '2022-01-12 16:28:17', '2022-01-12 16:28:17', 11, 2, 5);
INSERT INTO `notifications` VALUES (51, 'grade_review_reply', '2022-01-12 16:28:48', '2022-01-12 16:28:48', 11, 2, 5);
INSERT INTO `notifications` VALUES (52, 'finalize_grade', '2022-01-13 04:37:24', '2022-01-13 04:37:24', 11, 2, 5);
INSERT INTO `notifications` VALUES (53, 'finalize_grade', '2022-01-13 04:37:24', '2022-01-13 04:37:24', 11, 4, 5);
INSERT INTO `notifications` VALUES (54, 'finalize_grade', '2022-01-13 04:38:44', '2022-01-13 04:38:44', 11, 4, 5);
INSERT INTO `notifications` VALUES (55, 'finalize_grade', '2022-01-13 04:38:44', '2022-01-13 04:38:44', 11, 2, 5);
INSERT INTO `notifications` VALUES (56, 'finalize_grade', '2022-01-13 04:38:52', '2022-01-13 04:38:52', 11, 4, 5);
INSERT INTO `notifications` VALUES (57, 'finalize_grade', '2022-01-13 04:38:52', '2022-01-13 04:38:52', 11, 2, 5);
INSERT INTO `notifications` VALUES (58, 'finalize_grade', '2022-01-13 04:39:00', '2022-01-13 04:39:00', 11, 2, 5);
INSERT INTO `notifications` VALUES (59, 'finalize_grade', '2022-01-13 04:39:00', '2022-01-13 04:39:00', 11, 4, 5);
INSERT INTO `notifications` VALUES (80, 'grade_review_request', '2022-01-18 14:24:33', '2022-01-18 14:24:33', 12, 4, 2);
INSERT INTO `notifications` VALUES (81, 'grade_review_request', '2022-01-18 14:24:33', '2022-01-18 14:24:33', 12, 2, 2);
INSERT INTO `notifications` VALUES (82, 'grade_review_request', '2022-01-18 14:24:33', '2022-01-18 14:24:33', 12, 13, 2);
INSERT INTO `notifications` VALUES (83, 'grade_review_request', '2022-01-18 14:24:50', '2022-01-18 14:24:50', 12, 2, 2);
INSERT INTO `notifications` VALUES (84, 'grade_review_request', '2022-01-18 14:24:50', '2022-01-18 14:24:50', 12, 4, 2);
INSERT INTO `notifications` VALUES (85, 'grade_review_request', '2022-01-18 14:24:50', '2022-01-18 14:24:50', 12, 13, 2);
INSERT INTO `notifications` VALUES (86, 'grade_review_reply', '2022-01-18 14:25:22', '2022-01-18 14:25:22', 4, 12, 2);
INSERT INTO `notifications` VALUES (87, 'grade_review_final', '2022-01-18 14:25:55', '2022-01-18 14:25:55', 4, 12, 2);
INSERT INTO `notifications` VALUES (88, 'grade_review_final', '2022-01-18 14:26:13', '2022-01-18 14:26:13', 4, 12, 2);
INSERT INTO `notifications` VALUES (89, 'finalize_grade', '2022-01-18 15:43:34', '2022-01-18 15:43:34', 2, 4, 4);
INSERT INTO `notifications` VALUES (90, 'finalize_grade', '2022-01-18 15:43:34', '2022-01-18 15:43:34', 2, 17, 4);
INSERT INTO `notifications` VALUES (91, 'finalize_grade', '2022-01-18 15:43:34', '2022-01-18 15:43:34', 2, 43, 4);

-- ----------------------------
-- Table structure for resetPasswordTokens
-- ----------------------------
DROP TABLE IF EXISTS `resetPasswordTokens`;
CREATE TABLE `resetPasswordTokens`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `token` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `createdAt` datetime(0) NOT NULL,
  `updatedAt` datetime(0) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `id`(`id`) USING BTREE,
  UNIQUE INDEX `userId`(`userId`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 8 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of resetPasswordTokens
-- ----------------------------
INSERT INTO `resetPasswordTokens` VALUES (3, 2, '406f856f26b7b338ff9964f37b9d5cbd713bbdcc410a3567e3f747b84863a6fc', '2022-01-14 08:12:27', '2022-01-14 08:12:27');
INSERT INTO `resetPasswordTokens` VALUES (6, 14, '225f708bdb10f47c7044daf2ca1d4453d45a133011452093b24085dce19b46cd', '2022-01-18 12:23:59', '2022-01-18 12:23:59');
INSERT INTO `resetPasswordTokens` VALUES (7, 41, 'd86f62786e9eeed443ccb53fb99692c9e121e1b2a6fbdccab53fdb57084783f2', '2022-01-18 12:25:08', '2022-01-18 12:25:08');

-- ----------------------------
-- Table structure for studentFullnames
-- ----------------------------
DROP TABLE IF EXISTS `studentFullnames`;
CREATE TABLE `studentFullnames`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `studentId` int(11) NULL DEFAULT NULL,
  `fullName` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `createdAt` datetime(0) NOT NULL,
  `updatedAt` datetime(0) NOT NULL,
  `classId` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `id`(`id`) USING BTREE,
  INDEX `classId`(`classId`) USING BTREE,
  CONSTRAINT `studentFullnames_ibfk_1` FOREIGN KEY (`classId`) REFERENCES `classes` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 44 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of studentFullnames
-- ----------------------------
INSERT INTO `studentFullnames` VALUES (19, 18120593, ' Quang Tiến Tr', '2021-12-19 16:36:47', '2021-12-19 16:37:14', 5);
INSERT INTO `studentFullnames` VALUES (20, 18120512, 'Trịnh Quang Tiến', '2021-12-19 16:36:47', '2021-12-19 16:36:47', 5);
INSERT INTO `studentFullnames` VALUES (21, 18120592, 'Trần Quang Tiến', '2021-12-20 02:21:08', '2021-12-20 02:21:08', 5);
INSERT INTO `studentFullnames` VALUES (22, 18120511, ' Quang Tiến Tr', '2021-12-20 02:21:08', '2021-12-20 02:21:08', 5);
INSERT INTO `studentFullnames` VALUES (23, 18120569, 'Do Hoang The', '2021-12-20 03:36:02', '2021-12-20 03:36:02', 2);
INSERT INTO `studentFullnames` VALUES (24, 18120160, 'Hua Huy Cuong', '2021-12-20 03:36:03', '2021-12-20 03:36:03', 2);
INSERT INTO `studentFullnames` VALUES (25, 18120593, 'Tran Quang Tien', '2021-12-20 03:36:03', '2021-12-20 03:36:03', 2);
INSERT INTO `studentFullnames` VALUES (32, 18120500, 'a', '2021-12-20 13:40:43', '2021-12-20 13:40:43', 5);
INSERT INTO `studentFullnames` VALUES (33, 18120010, 'b', '2021-12-20 13:40:44', '2021-12-20 13:40:44', 5);
INSERT INTO `studentFullnames` VALUES (37, 18120160, 'Huy Cường', '2021-12-20 18:54:43', '2022-01-18 15:21:44', 4);
INSERT INTO `studentFullnames` VALUES (38, 18120593, 'Trần Quang Tiến', '2021-12-20 18:54:44', '2021-12-20 18:54:44', 4);
INSERT INTO `studentFullnames` VALUES (39, 18120569, 'Đỗ Hoàng Thế', '2021-12-20 18:54:44', '2021-12-20 18:54:44', 4);
INSERT INTO `studentFullnames` VALUES (40, 18120160, 'Hứa Huy Cường', '2021-12-20 18:54:43', '2021-12-20 18:54:43', 5);
INSERT INTO `studentFullnames` VALUES (50, 18120160, 'Cuong', '2022-01-18 15:08:23', '2022-01-18 15:08:23', 9);
INSERT INTO `studentFullnames` VALUES (51, 18120569, 'The', '2022-01-18 15:08:24', '2022-01-18 15:08:24', 9);
INSERT INTO `studentFullnames` VALUES (52, 123, 'Nguyễn Văn An', '2022-01-18 15:21:44', '2022-01-18 15:21:44', 4);

-- ----------------------------
-- Table structure for teacherWaitings
-- ----------------------------
DROP TABLE IF EXISTS `teacherWaitings`;
CREATE TABLE `teacherWaitings`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mail` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `createdAt` datetime(0) NOT NULL,
  `updatedAt` datetime(0) NOT NULL,
  `classId` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `id`(`id`) USING BTREE,
  INDEX `classId`(`classId`) USING BTREE,
  CONSTRAINT `teacherWaitings_ibfk_1` FOREIGN KEY (`classId`) REFERENCES `classes` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 10 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of teacherWaitings
-- ----------------------------
INSERT INTO `teacherWaitings` VALUES (1, 'hoangthe2249@gmail.com', '2021-11-25 02:46:10', '2021-11-25 02:46:10', 2);
INSERT INTO `teacherWaitings` VALUES (2, 'hoangthe2249@gmail.com', '2021-11-25 02:49:48', '2021-11-25 02:49:48', 2);
INSERT INTO `teacherWaitings` VALUES (3, 'hoangthe2429@gmail.com', '2022-01-08 00:01:19', '2022-01-08 00:01:19', 2);
INSERT INTO `teacherWaitings` VALUES (4, 'hoangthe1111@gmail.com', '2022-01-08 00:01:19', '2022-01-08 00:01:19', 2);
INSERT INTO `teacherWaitings` VALUES (5, 'hoangthe1122@gmail.com', '2022-01-08 00:09:09', '2022-01-08 00:09:09', 2);
INSERT INTO `teacherWaitings` VALUES (6, 'huycuong11399@gmail.com', '2022-01-08 00:09:09', '2022-01-08 00:09:09', 2);
INSERT INTO `teacherWaitings` VALUES (7, 'hoangthe1208@gmail.com', '2022-01-14 06:28:26', '2022-01-14 06:28:26', 2);
INSERT INTO `teacherWaitings` VALUES (8, 'hoangthe1208@gmail.com', '2022-01-18 03:40:50', '2022-01-18 03:40:50', 2);
INSERT INTO `teacherWaitings` VALUES (9, 'dewof89961@leezro.com', '2022-01-18 12:41:55', '2022-01-18 12:41:55', 14);

-- ----------------------------
-- Table structure for user_classes
-- ----------------------------
DROP TABLE IF EXISTS `user_classes`;
CREATE TABLE `user_classes`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `createdAt` datetime(0) NOT NULL,
  `updatedAt` datetime(0) NOT NULL,
  `classId` int(11) NULL DEFAULT NULL,
  `userId` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `id`(`id`) USING BTREE,
  UNIQUE INDEX `user_classes_userId_classId_unique`(`classId`, `userId`) USING BTREE,
  INDEX `userId`(`userId`) USING BTREE,
  CONSTRAINT `user_classes_ibfk_1` FOREIGN KEY (`classId`) REFERENCES `classes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `user_classes_ibfk_2` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 40 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of user_classes
-- ----------------------------
INSERT INTO `user_classes` VALUES (1, 'teacher', '2021-11-24 14:04:43', '2021-11-24 14:04:43', 2, 4);
INSERT INTO `user_classes` VALUES (3, 'teacher', '2021-11-24 14:06:02', '2021-11-24 14:06:02', 3, 4);
INSERT INTO `user_classes` VALUES (4, 'teacher', '2021-11-24 14:08:23', '2021-11-24 14:08:23', 4, 2);
INSERT INTO `user_classes` VALUES (5, 'student', '2021-11-25 02:51:29', '2021-11-25 02:51:29', 2, 12);
INSERT INTO `user_classes` VALUES (6, 'teacher', '2021-11-29 14:04:52', '2021-11-29 14:04:52', 5, 11);
INSERT INTO `user_classes` VALUES (7, 'teacher', '2021-11-30 07:04:01', '2021-11-30 07:04:01', 6, 2);
INSERT INTO `user_classes` VALUES (8, 'teacher', '2021-11-30 09:25:58', '2021-11-30 09:25:58', 7, 2);
INSERT INTO `user_classes` VALUES (9, 'student', '2021-11-30 16:50:16', '2021-11-30 16:50:16', 6, 10);
INSERT INTO `user_classes` VALUES (10, 'teacher', '2021-11-30 16:54:25', '2021-11-30 16:54:25', 8, 10);
INSERT INTO `user_classes` VALUES (11, 'student', '2021-12-16 02:36:56', '2021-12-16 02:36:56', 3, 13);
INSERT INTO `user_classes` VALUES (12, 'teacher', '2021-12-19 11:20:38', '2021-12-19 11:20:38', 9, 4);
INSERT INTO `user_classes` VALUES (16, 'teacher', '2021-12-19 13:09:38', '2021-12-19 13:09:38', 10, 4);
INSERT INTO `user_classes` VALUES (23, 'student', '2021-12-19 13:47:57', '2021-12-19 13:47:57', 7, 4);
INSERT INTO `user_classes` VALUES (24, 'teacher', '2021-12-22 03:42:01', '2021-12-22 03:42:01', 11, 14);
INSERT INTO `user_classes` VALUES (25, 'student', '2021-12-31 09:34:33', '2021-12-31 09:34:33', 5, 4);
INSERT INTO `user_classes` VALUES (27, 'teacher', '2022-01-08 00:09:09', '2022-01-08 00:09:09', 2, 2);
INSERT INTO `user_classes` VALUES (29, 'teacher', '2022-01-18 03:44:19', '2022-01-18 03:44:19', 2, 13);
INSERT INTO `user_classes` VALUES (33, 'student', '2022-01-18 04:48:07', '2022-01-18 04:48:07', 2, 40);
INSERT INTO `user_classes` VALUES (34, 'student', '2022-01-18 10:49:49', '2022-01-18 10:49:49', 8, 4);
INSERT INTO `user_classes` VALUES (35, 'teacher', '2022-01-18 12:39:43', '2022-01-18 12:39:43', 14, 2);
INSERT INTO `user_classes` VALUES (36, 'student', '2022-01-18 12:41:08', '2022-01-18 12:41:08', 2, 43);
INSERT INTO `user_classes` VALUES (37, 'teacher', '2022-01-18 12:41:55', '2022-01-18 12:41:55', 14, 43);
INSERT INTO `user_classes` VALUES (38, 'student', '2022-01-18 12:44:34', '2022-01-18 12:44:34', 6, 43);
INSERT INTO `user_classes` VALUES (39, 'student', '2022-01-18 14:33:09', '2022-01-18 14:33:09', 4, 43);
INSERT INTO `user_classes` VALUES (42, 'student', '2022-01-18 15:29:52', '2022-01-18 15:29:52', 4, 4);
INSERT INTO `user_classes` VALUES (43, 'student', '2022-01-18 15:30:42', '2022-01-18 15:30:42', 11, 4);
INSERT INTO `user_classes` VALUES (44, 'student', '2022-01-18 15:32:19', '2022-01-18 15:32:19', 6, 4);
INSERT INTO `user_classes` VALUES (45, 'student', '2022-01-18 15:35:40', '2022-01-18 15:35:40', 4, 17);

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `fullname` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `studentId` int(11) NULL DEFAULT NULL,
  `createdAt` datetime(0) NOT NULL,
  `updatedAt` datetime(0) NOT NULL,
  `isAdmin` tinyint(1) NULL DEFAULT 0,
  `status` tinyint(1) NULL DEFAULT 1,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `id`(`id`) USING BTREE,
  UNIQUE INDEX `username`(`username`) USING BTREE,
  UNIQUE INDEX `email`(`email`) USING BTREE,
  UNIQUE INDEX `studentId`(`studentId`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 44 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users` VALUES (2, 'centro', 'huycuong11399@gmail.com', '$2a$10$9Mk.jxS5/lumVu6l/QYCr.613cFBRW10hFI6lSF6TyE0ucAa.KlZ2', 'Cu♥☺ss 2341', 18120160, '2021-11-24 13:41:19', '2022-01-12 05:36:51', 0, 1);
INSERT INTO `users` VALUES (3, 'pepsi', 'cola@gmail.com', '$2a$10$PCV0hCRhKLlT2UjyXOpJN.8jqoZABXJ3qrSLXOPJU1AmpsyRQ2iCu', 'Writer 1', NULL, '2021-11-24 13:43:42', '2021-11-24 13:43:42', 0, 1);
INSERT INTO `users` VALUES (4, 'hoangthe2924', 'hoangthe2924@gmail.com', '$2a$10$/YJl53g6xiVas3X6mB.gGuQTae2q0UrnHVgP08Qxnuptvf2/6ThCG', 'Hoang-The Do', NULL, '2021-11-24 13:58:45', '2022-01-18 07:47:00', 0, 1);
INSERT INTO `users` VALUES (10, 'cuong', 'huyc.uong11399@gmail.com', '$2a$10$kqYi974Dy8Uiqnhg07g.tuHL31be9jIV7OmblwqeJWJAGuhW/WaN2', 'Cuong adm', NULL, '2021-11-24 14:35:23', '2022-01-12 04:46:49', 1, 1);
INSERT INTO `users` VALUES (11, 'tqtnk2000@gmail.com', 'tqtnk2000@gmail.com', NULL, 'Trần Quang Tiến', 18120593, '2021-11-25 02:30:10', '2022-01-12 08:06:42', 0, 1);
INSERT INTO `users` VALUES (12, 'hoangthe2249@gmail.com', 'hoangthe2249@gmail.com', NULL, 'The Hoang', 18120569, '2021-11-25 02:51:13', '2022-01-12 08:06:45', 0, 1);
INSERT INTO `users` VALUES (13, 'hoangthe2429', 'hoangthe2429@gmail.com', '$2a$10$u/kDeFC3vFmto9PpjFa5EeOuIvWtEgPCO7qgFlgKacuENfYmk4jBy', 'The Do Quang', NULL, '2021-12-16 02:36:39', '2021-12-16 02:36:39', 0, 1);
INSERT INTO `users` VALUES (14, 'cuonghua@kms-technology.com', 'cuonghua@kms-technology.com', '$2a$10$qBphSlXTEMG5U3lZOWP4wufjG0Rpu7kv5x6wOXI46P2q/c1Qxq9wa', 'Cuong Hua', NULL, '2021-12-22 03:38:37', '2022-01-14 09:31:17', 0, 1);
INSERT INTO `users` VALUES (15, 'sungneem@gmail.com', 'sungneem@gmail.com', NULL, 'sung ta', NULL, '2021-12-22 03:45:18', '2022-01-12 04:31:56', 0, 1);
INSERT INTO `users` VALUES (16, 'huy.cuong', 'huy.cuong11399@gmail.com', '$2a$10$rOaxIqw4T5fvrl4Hs6YaUeLFx8kDVQLjxNwo3UlSHLri2g54t7VnS', 'huy . cuong he', NULL, '2022-01-10 10:24:58', '2022-01-13 20:24:08', 0, 1);
INSERT INTO `users` VALUES (17, 'cuonghua', 'h.uycuong11399@gmail.com', '$2a$10$AiohyP9FbcOy0QF396o7muQeYmjKBMeHgfv9spLE.BkmnSnuXvR3i', 'Cường', 123, '2022-01-11 18:19:29', '2022-01-18 15:43:04', 0, 1);
INSERT INTO `users` VALUES (19, 'adminC', 'hu.ycuong11399@gmail.com', '$2a$10$XQhdJbB3ilbEyYnw2vGJZeyDKnLYHrYBhGMdjlI72SzQg8cjCOFpC', 'Hí', 113, '2022-01-12 05:55:17', '2022-01-12 05:58:56', 1, 1);
INSERT INTO `users` VALUES (20, 'adminT', 'admint@gmail.com', '$2a$10$V5WraRJRNe3AmyTdFhVVmuYgmr8Lc36HBVkFBGUZ51DaSoGCLVjsa', 'Tien Ga', NULL, '2022-01-12 08:18:16', '2022-01-12 08:18:27', 1, 1);
INSERT INTO `users` VALUES (25, 'admin', 'huycuong.11399@gmail.com', '$2a$10$PQ9vEW0yMPs84nrYbYqMpuu5njXQx/gUC8DMyh9A51mTCgCTOkR3S', 'Admin', NULL, '2022-01-13 14:09:27', '2022-01-13 14:09:27', 1, 1);
INSERT INTO `users` VALUES (29, 'tqtnk20001', 'tqtnk20001@gmail.com', '$2a$10$WurvNemSD9oUraB5ANrPx.U5EfdnTXltMMtM.hmjOJAwkgR9Uh7ia', 'Trần Quang Tiến', NULL, '2022-01-14 08:44:07', '2022-01-14 08:44:07', 0, 2);
INSERT INTO `users` VALUES (37, 'huycu.ong', 'huycu.ong11399@gmail.com', '$2a$10$JHzWT25AXbip0QZDsXijNefRFxjzvMT8qioXpCswCQdGxXspgC1qO', 'huycu.ong', NULL, '2022-01-17 15:58:35', '2022-01-17 16:15:55', 0, 1);
INSERT INTO `users` VALUES (38, 'admin_the', 'admin.the@gmail.com', '$2a$10$.hkRYF4oWPBo1D4W45xEGOMRjmFbl8F9IUkNWyWF5RZimQKf86tmm', 'The Admin', NULL, '2022-01-18 03:37:51', '2022-01-18 03:37:51', 1, 1);
INSERT INTO `users` VALUES (39, 'tusacnguyen', 'tusacnguyen@gmail.com', '$2a$10$BSvys11PbxRhuhEpiyCpdOqG2OLTMnqcAbZ7fRu6phIXzDdvqlBgq', 'Nguyễn Ngọc Tư', NULL, '2022-01-18 03:46:03', '2022-01-18 03:46:03', 0, 1);
INSERT INTO `users` VALUES (40, 'tuantutran', 'tuantutran@gmail.com', '$2a$10$R7Z0uuH5X6VjYM5Bh7mxIODfjbV9RX81XNkR7EAKRMFRRCb0vvm0S', 'Trần Tuấn Tú', NULL, '2022-01-18 03:46:39', '2022-01-18 03:46:39', 0, 1);
INSERT INTO `users` VALUES (41, 'cuon.ghua', 'cuon.ghua@kms-technology.com', '$2a$10$gyiXxhGADI9J8tkn9NTRM.pgTPczuFdT4WBKomQP4ggNtKwK9aPYy', 'Cuong Hua', NULL, '2022-01-18 12:22:38', '2022-01-18 12:22:38', 0, 2);
INSERT INTO `users` VALUES (42, 'ch', 'cuong.hua@kms-technology.com', '$2a$10$pcVGQx2rgz4yKmbpR5P9IeVNOAa2cWJJDx/k/XdfEpSiQPl814hMq', 'CH', NULL, '2022-01-18 12:25:44', '2022-01-18 12:25:44', 0, 2);
INSERT INTO `users` VALUES (43, 'dewof89961', 'dewof89961@leezro.com', '$2a$10$leAaRhdaErHIbW965ig2vuF5jsvuBDL/g0ANenB3HYs6jxvcH/Esu', 'dewof', 18120120, '2022-01-18 12:28:30', '2022-01-18 16:17:47', 0, 1);
INSERT INTO `users` VALUES (44, 'admin_test', 'huycuo.ng11399@gmail.com', '$2a$10$FIKlSu23HIdZUMT0DqqNJOoWaO2PTWSrQa1mLhh5tK5ilLzRBBD1C', 'Demo Test Admin', NULL, '2022-01-18 16:15:30', '2022-01-18 16:15:30', 1, 1);

SET FOREIGN_KEY_CHECKS = 1;
